<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


require_once('TechTGPHP/autoload.php'); // БИБЛИОТЕКА

use TechTGPHP\tg_api\TechTGPHP; // Основной класс

// Здесь ваш токен от бота Telegram
$token = 'TOKEN';

$bot = new TechTGPHP($token);

$update = json_decode(file_get_contents('php://input'), true); // получаем JSON

// Проверяем, что пришло обновление тоесть сообщение что за пришло
if (isset($update['message'])) {
    $chatId = $update['message']['chat']['id']; // ID чата
    $text = $update['message']['text']; // что за сообщение пришло.

    // Обработка команды /start
    if ($text == '/start') {
        $bot->sendMessage($chatId, "Привет! Я ваш тестовый бот. Добро пожаловать! "); // Обычное ввод сообщения
    }

if ($text === '/knop') { // кнопки это клавиатура наша 
    $bot->sendMessageWithButton($chatId, 'Привет! Нажми на кнопку.', 'Нажми меня'); // Текст и 2 аргумент выводить кнопку (клавиатуру)
}

if ($text === '/doc') { // способ отправки документа
    $documentPath = 'doc.txt'; // Абсолютный путь к файлу
    $absolutePath = realpath($documentPath);  // Получение абсолютного пути к файлу

    if ($absolutePath) {
        $bot->sendDocument($chatId, $absolutePath, 'Описание документа');
    } else {
        $bot->sendMessage($chatId, "Файл не найден"); // Если документ не найден то выводить ошибку
    }
}

if ($text === '/foto') {
	
	$foto = 'foto.jpg'; // Абсолютный путь к файлу
$photoPath = realpath($foto);  // Получение абсолютного пути к файлу
$caption = 'Текст сообщения по желанию можно пустым сделать';  // Опциональный подпись к фото

$response = $bot->sendPhoto($chatId, $photoPath, $caption);
	
}

  
}
