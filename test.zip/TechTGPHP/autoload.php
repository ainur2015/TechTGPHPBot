<?php
namespace TechTGPHP\vk_api;
$path_dir =  __DIR__.'/src';
require_once($path_dir.'/TechTGPHP.php');
